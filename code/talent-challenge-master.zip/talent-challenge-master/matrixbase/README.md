# Programming Test For Infrastructure

This repository contains coding problems used for infrastructure engineering candidates, including distributed system, query optimization, performance,...,etc. 

